		<div class="form-group">
			<?php echo Form::label('Propietario:'); ?>

			<select name="propietario_id" class="form-control">
				<?php foreach($propietarios as $propietario): ?>
				<option value="<?php echo e($propietario->id); ?>" <?php echo e((isset($vehiculo) AND ($vehiculo->propietario_id == $propietario->id)) ? 'selected' : ''); ?> > <?php echo e($propietario->nombre); ?> </option>
			  	<?php endforeach; ?>
			</select>
		</div>

		<div class="form-group">
			<?php echo Form::label('Modelo:'); ?>

			<select name="modelo_id" class="form-control">
				<?php foreach($modelos as $modelo): ?>
				<option value="<?php echo e($modelo->id); ?>" <?php echo e((isset($vehiculo) AND ($vehiculo->modelo_id == $modelo->id)) ? 'selected' : ''); ?> > <?php echo e($modelo->nombre); ?> </option>
			  	<?php endforeach; ?>
			</select>
		</div>

		<?php echo Form::submit('Enviar', ['class'=>'btn btn-primary']); ?>

		<a href="<?php echo e(route('vehiculos.index')); ?>" class="btn btn-info">Volver</a>

	<?php echo Form::close(); ?>