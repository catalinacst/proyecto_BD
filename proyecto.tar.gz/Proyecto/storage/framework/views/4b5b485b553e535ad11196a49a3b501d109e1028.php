<?php $__env->startSection('content'); ?>

	<h2><?php echo e($propietario->nombre); ?> <small><?php echo e($propietario->id + 1093228750); ?></small> </h2>

	<h3>Vehiculos</h3>
	<hr>
	<table class="table table-hover">
		<thead>
			<th>Placas</th>
			<th>Modelo</th>
			<th>Fecha Matricula</th>
			<th>Editar</th>
		</thead>
		<?php foreach($propietario->vehiculos as $vehiculo): ?>
		<tbody>
			<td><?php echo e($vehiculo->id + 100); ?></td>
			<td><a href="<?php echo e(route('modelos.show', $vehiculo->modelo->id)); ?>"><?php echo e($vehiculo->modelo->nombre); ?></a></td>
			<td><?php echo e($vehiculo->fecha_matricula); ?></td>
			<td><a href="<?php echo e(route('vehiculos.edit', $vehiculo->id)); ?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a></td>
		</tbody>
		<?php endforeach; ?>
	</table>
	<br>
	<h3>Infracciones</h3>
	<hr>
	<table class="table table-hover">
		<thead>
			<th>ID</th>
			<th>Agente</th>
			<th>Dirección</th>
			<th>Articulo</th>
			<th>Valor Total</th>
			<th>Editar</th>
		</thead>
		<?php foreach($propietario->infracciones as $infraccion): ?>
		<tbody>
			<td><?php echo e($infraccion->id); ?></td>
			<td><?php echo e($infraccion->agente->nombre); ?></td>
			<td><?php echo e($infraccion->direccion->carrera); ?></td>
			<td><?php echo e($infraccion->articulo); ?></td>
			<td><?php echo e($infraccion->valor_total); ?></td>
			<td><a href="<?php echo e(route('infracciones.edit', $infraccion->id)); ?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a></td>
		</tbody>
		<?php endforeach; ?>
	</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>