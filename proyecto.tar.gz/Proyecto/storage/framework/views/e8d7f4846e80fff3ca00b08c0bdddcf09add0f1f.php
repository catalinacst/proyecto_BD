<?php $__env->startSection('content'); ?>

	<?php if(Session::has('msg')): ?>
		<div class="alert alert-success alert-dismissible" role="alert">
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <span class="glyphicon glyphicon-ok" aria-hidden="true"></span><strong> Bien hecho! </strong> <?php echo e(Session::get('msg')); ?>

		</div>
	<?php endif; ?>

	<h2>Direcciones</h2>
	<hr>

	<table class="table table-hover">
		<thead>
			<th>Carrera</th>
			<th>Kilometro</th>
		</thead>
		<?php foreach($direcciones as $direccion): ?>
		<tbody>
			<td><?php echo e($direccion->carrera); ?></td>
			<td><?php echo e($direccion->kilometro); ?></td>
		</tbody>
		<?php endforeach; ?>
	</table>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>