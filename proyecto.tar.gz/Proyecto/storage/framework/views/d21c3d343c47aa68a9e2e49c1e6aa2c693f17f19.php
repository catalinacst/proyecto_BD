<?php $__env->startSection('content'); ?>

	<h2><?php echo e($marca->nombre); ?> <small><?php echo e($marca->direccion); ?></small> </h2>
	<hr>

	<table class="table table-hover">
		<thead>
			<th>Nombre</th>
			<th>Potencia</th>
			<th>Editar</th>
		</thead>
		<?php foreach($marca->modelos as $modelo): ?>
		<tbody>
			<td><a href="<?php echo e(route('modelos.show', $modelo->id)); ?>"><?php echo e($modelo->nombre); ?></a></td>
			<td><?php echo e($modelo->potencia); ?></td>
			<td><a href="<?php echo e(route('modelos.edit', $modelo->id)); ?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a></td>
		</tbody>
		<?php endforeach; ?>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>