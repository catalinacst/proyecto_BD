		<div class="form-group">
			<?php echo Form::label('Propietario:'); ?>

			<select name="propietario_id" class="form-control">
				<?php foreach($propietarios as $propietario): ?>
				<option value="<?php echo e($propietario->id); ?>" <?php echo e((isset($infraccion) AND ($infraccion->propietario_id == $propietario->id)) ? 'selected' : ''); ?> > <?php echo e($propietario->nombre); ?> </option>
			  	<?php endforeach; ?>
			</select>
		</div>

		<div class="form-group">
			<?php echo Form::label('Agente:'); ?>

			<select name="agente_id" class="form-control">
				<?php foreach($agentes as $agente): ?>
				<option value="<?php echo e($agente->id); ?>" <?php echo e((isset($infraccion) AND ($infraccion->agente_id == $agente->id)) ? 'selected' : ''); ?> > <?php echo e($agente->nombre); ?> </option>
			  	<?php endforeach; ?>
			</select>
		</div>

		<div class="form-group">
			<?php echo Form::label('Dirección:'); ?>

			<select name="direccion_id" class="form-control">
				<?php foreach($direcciones as $direccion): ?>
				<option value="<?php echo e($direccion->id); ?>" <?php echo e((isset($infraccion) AND ($infraccion->direccion_id == $direccion->id)) ? 'selected' : ''); ?> > <?php echo e($direccion->carrera); ?> </option>
			  	<?php endforeach; ?>
			</select>
		</div>

		<div class="form-group">
			<?php echo Form::label('Articulo:'); ?>

			<?php echo Form::text('articulo', null, ['class'=>'form-control', 'placeholder'=>'Insertar el articulo infringido']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('Valor Total:'); ?>

			<?php echo Form::text('valor_total', null, ['class'=>'form-control', 'placeholder'=>'Insertar el valor total de la infracción']); ?>

		</div>

		<?php echo Form::submit('Enviar', ['class'=>'btn btn-primary']); ?>

		<a href="<?php echo e(route('infracciones.index')); ?>" class="btn btn-info">Volver</a>

	<?php echo Form::close(); ?>