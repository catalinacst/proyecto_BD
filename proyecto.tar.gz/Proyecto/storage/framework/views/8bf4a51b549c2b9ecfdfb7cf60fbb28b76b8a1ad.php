		<div class="form-group">
			<?php echo Form::label('Nombre:'); ?>

			<?php echo Form::text('nombre', null, ['class'=>'form-control', 'placeholder'=>'Insertar el nombre del modelo']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('Potencia:'); ?>

			<?php echo Form::text('potencia', null, ['class'=>'form-control', 'placeholder'=>'Insertar la potencia del modelo']); ?>

		</div>

		<div class="form-group">
			<select name="marca_id" class="form-control">
				<?php foreach($marcas as $marca): ?>
				<option value="<?php echo e($marca->id); ?>" <?php echo e((isset($modelo) AND ($modelo->marca_id == $marca->id)) ? 'selected' : ''); ?> > <?php echo e($marca->nombre); ?> </option>
			  	<?php endforeach; ?>
			</select>
		</div>

		<?php echo Form::submit('Enviar', ['class'=>'btn btn-primary']); ?>

		<a href="<?php echo e(route('modelos.index')); ?>" class="btn btn-info">Volver</a>

	<?php echo Form::close(); ?>