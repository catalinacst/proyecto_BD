<?php $__env->startSection('content'); ?>

	<?php if(Session::has('msg')): ?>
		<div class="alert alert-success alert-dismissible" role="alert">
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <span class="glyphicon glyphicon-ok" aria-hidden="true"></span><strong> Bien hecho! </strong> <?php echo e(Session::get('msg')); ?>

		</div>
	<?php endif; ?>

	<h2>Infracciones</h2>
	<a href="<?php echo e(route('infracciones.create')); ?>" class="btn btn-primary">Agregar</a>
	<hr>

	<table class="table table-hover">
		<thead>
			<th>ID</th>
			<th>Propietario</th>
			<th>Agente</th>
			<th>Direccion</th>
			<th>Articulo</th>
			<th>Valor Total</th>
			<th>Editar</th>
		</thead>
		<?php foreach($infracciones as $infraccion): ?>
		<tbody>
			<td><?php echo e($infraccion->id); ?></td>
			<td><a href="<?php echo e(route('propietarios.show', $infraccion->propietario->id)); ?>"><?php echo e($infraccion->propietario->nombre); ?></a></td>
			<td><?php echo e($infraccion->agente->nombre); ?></td>
			<td><?php echo e($infraccion->direccion->carrera); ?></td>
			<td><?php echo e($infraccion->articulo); ?></td>
			<td><?php echo e($infraccion->valor_total); ?></td>
			<td><a href="<?php echo e(route('infracciones.edit', $infraccion->id)); ?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a></td>
		</tbody>
		<?php endforeach; ?>
	</table>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>