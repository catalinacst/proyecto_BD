	<div class="form-group">
		<?php echo Form::label('Nombre:'); ?>

		<?php echo Form::text('nombre', null, ['class'=>'form-control', 'placeholder'=>'Ingresar el nombre de la marca']); ?>

	</div>

	<div class="form-group">
		<?php echo Form::label('Direccion:'); ?>

		<?php echo Form::text('direccion', null, ['class'=>'form-control', 'placeholder'=>'Insertar la direccion de la marca']); ?>

	</div>

	<?php echo Form::submit('Enviar', ['class'=>'btn btn-primary']); ?>

	<a href="<?php echo e(route('marcas.index')); ?>" class="btn btn-info">Volver</a>

<?php echo Form::close(); ?>