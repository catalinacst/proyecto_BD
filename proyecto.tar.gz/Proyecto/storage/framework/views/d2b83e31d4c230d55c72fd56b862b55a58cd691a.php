<?php $__env->startSection('content'); ?>

	<?php if(count($errors)): ?>
		<?php echo $__env->make('errors.forms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>

	<h2>Update Category <?php echo e($marca->id); ?></h2>
	<hr>


	<?php echo Form::model($marca, ['route'=>['marcas.update', $marca->id], 'method'=>'PUT']); ?>

		<?php echo $__env->make('forms.marcas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<hr>

	<?php echo Form::open(['route'=>['marcas.destroy', $marca->id], 'method'=>'DELETE']); ?>

		<?php echo Form::submit('Eliminar', ['class'=>'btn btn-danger']); ?>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>