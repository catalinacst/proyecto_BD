<?php $__env->startSection('content'); ?>

	<?php if(Session::has('msg')): ?>
		<div class="alert alert-success alert-dismissible" role="alert">
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <span class="glyphicon glyphicon-ok" aria-hidden="true"></span><strong> Bien hecho! </strong> <?php echo e(Session::get('msg')); ?>

		</div>
	<?php endif; ?>

	<h2>Vehiculos</h2>
	<a href="<?php echo e(route('vehiculos.create')); ?>" class="btn btn-primary">Agregar</a>
	<hr>

	<table class="table table-hover">
		<thead>
			<th>Placa</th>
			<th>Propietario</th>
			<th>Modelo</th>
			<th>Fecha Matricula</th>
			<th>Editar</th>
		</thead>
		<?php foreach($vehiculos as $vehiculo): ?>
		<tbody>
			<td><?php echo e($vehiculo->id + 100); ?></td>
			<td><a href="<?php echo e(route('propietarios.show', $vehiculo->propietario->id)); ?>"><?php echo e($vehiculo->propietario->nombre); ?></a></td>
			<td><a href="<?php echo e(route('modelos.show', $vehiculo->modelo->id)); ?>"><?php echo e($vehiculo->modelo->nombre); ?></a></td>
			<td><?php echo e($vehiculo->created_at); ?></td>
			<td><a href="<?php echo e(route('vehiculos.edit', $vehiculo->id)); ?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a></td>
		</tbody>
		<?php endforeach; ?>
	</table>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>